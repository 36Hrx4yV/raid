# Discord Raid Bot

Discord Raidbot, a versatile Discord debugging and testing tool.

This bot is able to do a lot of harmfull things, so the creators of this bot (including me) are NOT responsible for what you do with this.
This bot was only made to learn Discord.Js and to test Discord's capabilities.

If you want you can try it out, but please only use it in your own servers.

Commands:

**/pmeveryone**
Sends everyone in the server a private message

**/channels (name)**
Creates 50 channels with (name)

**/spam (message)**
Sends (message) 50 times in channel where the command was issued.

**/deletechannels**
Warning! Deletes all channels!

**/deleteroles**
Warning! Deletes all roles!

**/spamall (message)**
Warning! Spams all channels with (message)

**/kickall**
EXTREME WARNING! Kicks everyone under the bot's hierarchy

**/banall**
EXTREME WARNING! Bans everyone under the bot's hierarchy

**/massnick (nick)**
Nicks everyone to (nickname)

**/guildname (name)**
Sets a new guildname
